<?php
require_once '../engine/ignition.php';

//Init Core Library
$init = new Core;