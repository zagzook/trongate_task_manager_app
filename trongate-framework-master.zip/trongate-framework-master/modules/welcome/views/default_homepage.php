<h1 class="mt-2">Enjoy Trongate!</h1>
<h2>The Native PHP Framework</h2>
<p class="mt-2">You have successfully installed Trongate. You're now ready to start building fast, efficient web applications.</p>

<div class="mt-3">
    <?php
    echo anchor('https://trongate.io', 'Visit Trongate.io', ['class' => 'button', 'target' => '_blank']);
    echo anchor('https://trongate.io/docs', 'View Documentation', ['class' => 'button alt', 'target' => '_blank']);
    ?>
</div>