<?php
//Settings to do with the identification of the site owner
define('WEBSITE_NAME', 'Trongate v2');
define('OUR_NAME', 'Your Company Name');
define('OUR_TELNUM', '');
define('OUR_ADDRESS', '');
define('OUR_EMAIL_ADDRESS', '');